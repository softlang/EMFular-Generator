import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { EcoreEditorComponent } from './ecore/editor/Ecore-editor.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, EcoreEditorComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class AppComponent {
  title = 'ecore-graphical-editor';

  constructor() {}
}
