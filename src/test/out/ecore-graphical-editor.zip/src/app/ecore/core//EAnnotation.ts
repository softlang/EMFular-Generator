import { eClass, reference, attribute } from 'emfular'
import type { EStringToStringMapEntry } from './EStringToStringMapEntry';
import type { EObject } from './EObject';
import type { ModelList } from 'emfular';
import { ecoreMeta, EAnnotationRefs } from './_meta_';
import { EModelElement } from './EModelElement';

@eClass(ecoreMeta, "EAnnotation")
export class EAnnotation extends EModelElement  {

  constructor() {
    super();
  }

  @attribute()
  source?: string;

  @reference(EAnnotationRefs.details)
  declare details: ModelList<EStringToStringMapEntry>;

  @reference(EAnnotationRefs.eModelElement)
  declare eModelElement: EModelElement;

  @reference(EAnnotationRefs.contents)
  declare contents: ModelList<EObject>;

  @reference(EAnnotationRefs.references)
  declare references: ModelList<EObject>;
}
