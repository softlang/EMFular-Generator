import { eClass, reference, attribute } from 'emfular'
import type { EDataType } from './EDataType';
import { ecoreMeta, EAttributeRefs } from './_meta_';
import { EStructuralFeature } from './EStructuralFeature';

@eClass(ecoreMeta, "EAttribute")
export class EAttribute extends EStructuralFeature  {

  constructor() {
    super();
  }

  @attribute()
  iD?: boolean;

  get eAttributeType(): EDataType {
		throw new Error('Method not implemented.'); //TODO
  }

}
