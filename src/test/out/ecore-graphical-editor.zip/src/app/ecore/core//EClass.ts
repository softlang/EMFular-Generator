import { eClass, reference, attribute } from 'emfular'
import type { EOperation } from './EOperation';
import type { EAttribute } from './EAttribute';
import type { EReference } from './EReference';
import type { EStructuralFeature } from './EStructuralFeature';
import type { EGenericType } from './EGenericType';
import type { ModelList } from 'emfular';
import { ecoreMeta, EClassRefs } from './_meta_';
import { EClassifier } from './EClassifier';

@eClass(ecoreMeta, "EClass")
export class EClass extends EClassifier  {

  constructor() {
    super();
  }

  @attribute()
  abstract?: boolean;

  @attribute()
  interface?: boolean;

  @reference(EClassRefs.eSuperTypes)
  declare eSuperTypes: ModelList<EClass>;

  @reference(EClassRefs.eOperations)
  declare eOperations: ModelList<EOperation>;

  get eAllAttributes(): EAttribute[] {
		throw new Error('Method not implemented.'); //TODO
  }


  get eAllReferences(): EReference[] {
		throw new Error('Method not implemented.'); //TODO
  }


  get eReferences(): EReference[] {
		throw new Error('Method not implemented.'); //TODO
  }


  get eAttributes(): EAttribute[] {
		throw new Error('Method not implemented.'); //TODO
  }


  get eAllContainments(): EReference[] {
		throw new Error('Method not implemented.'); //TODO
  }


  get eAllOperations(): EOperation[] {
		throw new Error('Method not implemented.'); //TODO
  }


  get eAllStructuralFeatures(): EStructuralFeature[] {
		throw new Error('Method not implemented.'); //TODO
  }


  get eAllSuperTypes(): EClass[] {
		throw new Error('Method not implemented.'); //TODO
  }


  get eIDAttribute(): EAttribute|undefined {
		throw new Error('Method not implemented.'); //TODO
  }


  @reference(EClassRefs.eStructuralFeatures)
  declare eStructuralFeatures: ModelList<EStructuralFeature>;

  @reference(EClassRefs.eGenericSuperTypes)
  declare eGenericSuperTypes: ModelList<EGenericType>;

  get eAllGenericSuperTypes(): EGenericType[] {
		throw new Error('Method not implemented.'); //TODO
  }

}
