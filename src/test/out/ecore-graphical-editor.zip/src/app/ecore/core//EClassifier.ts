import { eClass, reference, attribute } from 'emfular'
import type { EPackage } from './EPackage';
import type { ETypeParameter } from './ETypeParameter';
import type { ModelList } from 'emfular';
import { ecoreMeta, EClassifierRefs } from './_meta_';
import { ENamedElement } from './ENamedElement';

@eClass(ecoreMeta, "EClassifier")
export abstract class EClassifier extends ENamedElement  {

  constructor() {
    super();
  }

  @attribute()
  instanceClassName?: string;

  @attribute()
  instanceClass?: ;

  @attribute()
  defaultValue?: EJavaObject;

  @attribute()
  instanceTypeName?: string;

  @reference(EClassifierRefs.ePackage)
  declare ePackage: EPackage;

  @reference(EClassifierRefs.eTypeParameters)
  declare eTypeParameters: ModelList<ETypeParameter>;
}
