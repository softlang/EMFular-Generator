import { eClass, attribute } from 'emfular'
import { ecoreMeta } from './_meta_';
import { EClassifier } from './EClassifier';

@eClass(ecoreMeta, "EDataType")
export class EDataType extends EClassifier  {

  constructor() {
    super();
  }

  @attribute()
  serializable?: boolean = true;


}
