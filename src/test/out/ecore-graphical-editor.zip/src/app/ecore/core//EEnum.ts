import { eClass, reference } from 'emfular'
import type { EEnumLiteral } from './EEnumLiteral';
import type { ModelList } from 'emfular';
import { ecoreMeta, EEnumRefs } from './_meta_';
import { EDataType } from './EDataType';

@eClass(ecoreMeta, "EEnum")
export class EEnum extends EDataType  {

  constructor() {
    super();
  }



  @reference(EEnumRefs.eLiterals)
  declare eLiterals: ModelList<EEnumLiteral>;
}
