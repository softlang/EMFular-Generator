import { eClass, reference, attribute } from 'emfular'
import type { EEnum } from './EEnum';
import { ecoreMeta, EEnumLiteralRefs } from './_meta_';
import { ENamedElement } from './ENamedElement';

@eClass(ecoreMeta, "EEnumLiteral")
export class EEnumLiteral extends ENamedElement  {

  constructor() {
    super();
  }

  @attribute()
  value?: number;

  @attribute()
  instance?: EEnumerator;

  @attribute()
  literal?: string;

  @reference(EEnumLiteralRefs.eEnum)
  declare eEnum: EEnum;
}
