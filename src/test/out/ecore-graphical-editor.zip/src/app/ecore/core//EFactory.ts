import { eClass, reference } from 'emfular'
import type { EPackage } from './EPackage';
import { ecoreMeta, EFactoryRefs } from './_meta_';
import { EModelElement } from './EModelElement';

@eClass(ecoreMeta, "EFactory")
export class EFactory extends EModelElement  {

  constructor() {
    super();
  }



  @reference(EFactoryRefs.ePackage)
  declare ePackage: EPackage;
}
