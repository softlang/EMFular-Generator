import { eClass, reference } from 'emfular'
import type { EClassifier } from './EClassifier';
import type { ETypeParameter } from './ETypeParameter';
import type { ModelList } from 'emfular';
import { ecoreMeta, EGenericTypeRefs } from './_meta_';
import { Referencable } from 'emfular';

@eClass(ecoreMeta, "EGenericType")
export class EGenericType extends Referencable<any>  {

  constructor() {
    super();
  }



  @reference(EGenericTypeRefs.eUpperBound)
  declare eUpperBound: EGenericType;

  @reference(EGenericTypeRefs.eTypeArguments)
  declare eTypeArguments: ModelList<EGenericType>;

  get eRawType(): EClassifier {
		throw new Error('Method not implemented.'); //TODO
  }


  @reference(EGenericTypeRefs.eLowerBound)
  declare eLowerBound: EGenericType;

  @reference(EGenericTypeRefs.eTypeParameter)
  declare eTypeParameter: ETypeParameter;

  @reference(EGenericTypeRefs.eClassifier)
  declare eClassifier: EClassifier;
}
