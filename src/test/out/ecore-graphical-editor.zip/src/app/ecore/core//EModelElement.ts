import { eClass, reference } from 'emfular'
import type { EAnnotation } from './EAnnotation';
import type { ModelList } from 'emfular';
import { ecoreMeta, EModelElementRefs } from './_meta_';
import { Referencable } from 'emfular';

@eClass(ecoreMeta, "EModelElement")
export abstract class EModelElement extends Referencable<any>  {

  constructor() {
    super();
  }



  @reference(EModelElementRefs.eAnnotations)
  declare eAnnotations: ModelList<EAnnotation>;
}
