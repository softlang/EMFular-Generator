import { eClass, attribute } from 'emfular'
import { ecoreMeta } from './_meta_';
import { EModelElement } from './EModelElement';

@eClass(ecoreMeta, "ENamedElement")
export abstract class ENamedElement extends EModelElement  {

  constructor() {
    super();
  }

  @attribute()
  name?: string;


}
