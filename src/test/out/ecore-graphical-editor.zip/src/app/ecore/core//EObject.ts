import { eClass } from 'emfular'
import { ecoreMeta } from './_meta_';
import { Referencable } from 'emfular';

@eClass(ecoreMeta, "EObject")
export class EObject extends Referencable<any>  {

  constructor() {
    super();
  }




}
