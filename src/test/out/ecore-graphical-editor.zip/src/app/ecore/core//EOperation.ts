import { eClass, reference } from 'emfular'
import type { EClass } from './EClass';
import type { ETypeParameter } from './ETypeParameter';
import type { EParameter } from './EParameter';
import type { EClassifier } from './EClassifier';
import type { EGenericType } from './EGenericType';
import type { ModelList } from 'emfular';
import { ecoreMeta, EOperationRefs } from './_meta_';
import { ETypedElement } from './ETypedElement';

@eClass(ecoreMeta, "EOperation")
export class EOperation extends ETypedElement  {

  constructor() {
    super();
  }



  @reference(EOperationRefs.eContainingClass)
  declare eContainingClass: EClass;

  @reference(EOperationRefs.eTypeParameters)
  declare eTypeParameters: ModelList<ETypeParameter>;

  @reference(EOperationRefs.eParameters)
  declare eParameters: ModelList<EParameter>;

  @reference(EOperationRefs.eExceptions)
  declare eExceptions: ModelList<EClassifier>;

  @reference(EOperationRefs.eGenericExceptions)
  declare eGenericExceptions: ModelList<EGenericType>;
}
