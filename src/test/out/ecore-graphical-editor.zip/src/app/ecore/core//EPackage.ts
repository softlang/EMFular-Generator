import { eClass, reference, attribute } from 'emfular'
import type { EFactory } from './EFactory';
import type { EClassifier } from './EClassifier';
import type { ModelList } from 'emfular';
import { ecoreMeta, EPackageRefs } from './_meta_';
import { ENamedElement } from './ENamedElement';

@eClass(ecoreMeta, "EPackage")
export class EPackage extends ENamedElement  {

  constructor() {
    super();
  }

  @attribute()
  nsURI?: string;

  @attribute()
  nsPrefix?: string;

  @reference(EPackageRefs.eFactoryInstance)
  declare eFactoryInstance: EFactory;

  @reference(EPackageRefs.eClassifiers)
  declare eClassifiers: ModelList<EClassifier>;

  @reference(EPackageRefs.eSubpackages)
  declare eSubpackages: ModelList<EPackage>;

  @reference(EPackageRefs.eSuperPackage)
  declare eSuperPackage: EPackage;
}
