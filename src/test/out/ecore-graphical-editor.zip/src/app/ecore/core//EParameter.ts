import { eClass, reference } from 'emfular'
import type { EOperation } from './EOperation';
import { ecoreMeta, EParameterRefs } from './_meta_';
import { ETypedElement } from './ETypedElement';

@eClass(ecoreMeta, "EParameter")
export class EParameter extends ETypedElement  {

  constructor() {
    super();
  }



  @reference(EParameterRefs.eOperation)
  declare eOperation: EOperation;
}
