import { eClass, reference, attribute } from 'emfular'
import type { EClass } from './EClass';
import type { EAttribute } from './EAttribute';
import type { ModelList } from 'emfular';
import { ecoreMeta, EReferenceRefs } from './_meta_';
import { EStructuralFeature } from './EStructuralFeature';

@eClass(ecoreMeta, "EReference")
export class EReference extends EStructuralFeature  {

  constructor() {
    super();
  }

  @attribute()
  containment?: boolean;

  @attribute()
  container?: boolean;

  @attribute()
  resolveProxies?: boolean = true;

  @reference(EReferenceRefs.eOpposite)
  declare eOpposite: EReference;

  get eReferenceType(): EClass {
		throw new Error('Method not implemented.'); //TODO
  }


  @reference(EReferenceRefs.eKeys)
  declare eKeys: ModelList<EAttribute>;
}
