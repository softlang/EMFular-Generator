import { eClass, attribute } from 'emfular'
import { ecoreMeta } from './_meta_';
import { Referencable } from 'emfular';

@eClass(ecoreMeta, "EStringToStringMapEntry")
export class EStringToStringMapEntry extends Referencable<any>  {

  constructor() {
    super();
  }

  @attribute()
  key?: string;

  @attribute()
  value?: string;


}
