import { eClass, reference, attribute } from 'emfular'
import type { EClass } from './EClass';
import { ecoreMeta, EStructuralFeatureRefs } from './_meta_';
import { ETypedElement } from './ETypedElement';

@eClass(ecoreMeta, "EStructuralFeature")
export abstract class EStructuralFeature extends ETypedElement  {

  constructor() {
    super();
  }

  @attribute()
  changeable?: boolean = true;

  @attribute()
  volatile?: boolean;

  @attribute()
  transient?: boolean;

  @attribute()
  defaultValueLiteral?: string;

  @attribute()
  defaultValue?: EJavaObject;

  @attribute()
  unsettable?: boolean;

  @attribute()
  derived?: boolean;

  @reference(EStructuralFeatureRefs.eContainingClass)
  declare eContainingClass: EClass;
}
