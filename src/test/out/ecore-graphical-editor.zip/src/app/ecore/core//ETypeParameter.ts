import { eClass, reference } from 'emfular'
import type { EGenericType } from './EGenericType';
import type { ModelList } from 'emfular';
import { ecoreMeta, ETypeParameterRefs } from './_meta_';
import { ENamedElement } from './ENamedElement';

@eClass(ecoreMeta, "ETypeParameter")
export class ETypeParameter extends ENamedElement  {

  constructor() {
    super();
  }



  @reference(ETypeParameterRefs.eBounds)
  declare eBounds: ModelList<EGenericType>;
}
