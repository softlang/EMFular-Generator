import { eClass, reference, attribute } from 'emfular'
import type { EClassifier } from './EClassifier';
import type { EGenericType } from './EGenericType';
import { ecoreMeta, ETypedElementRefs } from './_meta_';
import { ENamedElement } from './ENamedElement';

@eClass(ecoreMeta, "ETypedElement")
export abstract class ETypedElement extends ENamedElement  {

  constructor() {
    super();
  }

  @attribute()
  ordered?: boolean = true;

  @attribute()
  unique?: boolean = true;

  @attribute()
  lowerBound?: number;

  @attribute()
  upperBound?: number = 1;

  @attribute()
  many?: boolean;

  @attribute()
  required?: boolean;

  @reference(ETypedElementRefs.eType)
  declare eType: EClassifier;

  @reference(ETypedElementRefs.eGenericType)
  declare eGenericType: EGenericType;
}
