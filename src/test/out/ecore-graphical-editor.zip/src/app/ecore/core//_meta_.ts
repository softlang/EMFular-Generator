import { ModelDefinition, ReferenceMeta } from "emfular";


export const EAttributeRefs = {
	eAttributeType: {
		target: "EDataType",
		max: 1,
		min: 1,
		//todo: derived
	} satisfies ReferenceMeta
};
export const EAnnotationRefs = {
	details: {
		target: "EStringToStringMapEntry",
		max: -1,
		containment: true
	} satisfies ReferenceMeta,
	eModelElement: {
		target: "EModelElement",
		max: 1,
		isParent: true,
		opposite: "eAnnotations"
	} satisfies ReferenceMeta,
	contents: {
		target: "EObject",
		max: -1,
		containment: true
	} satisfies ReferenceMeta,
	references: {
		target: "EObject",
		max: -1
	} satisfies ReferenceMeta
};
export const EClassRefs = {
	eSuperTypes: {
		target: "EClass",
		max: -1
	} satisfies ReferenceMeta,
	eOperations: {
		target: "EOperation",
		max: -1,
		containment: true,
		opposite: "eContainingClass"
	} satisfies ReferenceMeta,
	eAllAttributes: {
		target: "EAttribute",
		max: -1,
		//todo: derived
	} satisfies ReferenceMeta,
	eAllReferences: {
		target: "EReference",
		max: -1,
		//todo: derived
	} satisfies ReferenceMeta,
	eReferences: {
		target: "EReference",
		max: -1,
		//todo: derived
	} satisfies ReferenceMeta,
	eAttributes: {
		target: "EAttribute",
		max: -1,
		//todo: derived
	} satisfies ReferenceMeta,
	eAllContainments: {
		target: "EReference",
		max: -1,
		//todo: derived
	} satisfies ReferenceMeta,
	eAllOperations: {
		target: "EOperation",
		max: -1,
		//todo: derived
	} satisfies ReferenceMeta,
	eAllStructuralFeatures: {
		target: "EStructuralFeature",
		max: -1,
		//todo: derived
	} satisfies ReferenceMeta,
	eAllSuperTypes: {
		target: "EClass",
		max: -1,
		//todo: derived
	} satisfies ReferenceMeta,
	eIDAttribute: {
		target: "EAttribute",
		max: 1,
		//todo: derived
	} satisfies ReferenceMeta,
	eStructuralFeatures: {
		target: "EStructuralFeature",
		max: -1,
		containment: true,
		opposite: "eContainingClass"
	} satisfies ReferenceMeta,
	eGenericSuperTypes: {
		target: "EGenericType",
		max: -1,
		containment: true
	} satisfies ReferenceMeta,
	eAllGenericSuperTypes: {
		target: "EGenericType",
		max: -1,
		//todo: derived
	} satisfies ReferenceMeta
};
export const EClassifierRefs = {
	ePackage: {
		target: "EPackage",
		max: 1,
		isParent: true,
		opposite: "eClassifiers"
	} satisfies ReferenceMeta,
	eTypeParameters: {
		target: "ETypeParameter",
		max: -1,
		containment: true
	} satisfies ReferenceMeta
};
export const EDataTypeRefs = {
};
export const EEnumRefs = {
	eLiterals: {
		target: "EEnumLiteral",
		max: -1,
		containment: true,
		opposite: "eEnum"
	} satisfies ReferenceMeta
};
export const EEnumLiteralRefs = {
	eEnum: {
		target: "EEnum",
		max: 1,
		isParent: true,
		opposite: "eLiterals"
	} satisfies ReferenceMeta
};
export const EFactoryRefs = {
	ePackage: {
		target: "EPackage",
		max: 1,
		min: 1,
		opposite: "eFactoryInstance"
	} satisfies ReferenceMeta
};
export const EModelElementRefs = {
	eAnnotations: {
		target: "EAnnotation",
		max: -1,
		containment: true,
		opposite: "eModelElement"
	} satisfies ReferenceMeta
};
export const ENamedElementRefs = {
};
export const EObjectRefs = {
};
export const EOperationRefs = {
	eContainingClass: {
		target: "EClass",
		max: 1,
		isParent: true,
		opposite: "eOperations"
	} satisfies ReferenceMeta,
	eTypeParameters: {
		target: "ETypeParameter",
		max: -1,
		containment: true
	} satisfies ReferenceMeta,
	eParameters: {
		target: "EParameter",
		max: -1,
		containment: true,
		opposite: "eOperation"
	} satisfies ReferenceMeta,
	eExceptions: {
		target: "EClassifier",
		max: -1
	} satisfies ReferenceMeta,
	eGenericExceptions: {
		target: "EGenericType",
		max: -1,
		containment: true
	} satisfies ReferenceMeta
};
export const EPackageRefs = {
	eFactoryInstance: {
		target: "EFactory",
		max: 1,
		min: 1,
		opposite: "ePackage"
	} satisfies ReferenceMeta,
	eClassifiers: {
		target: "EClassifier",
		max: -1,
		containment: true,
		opposite: "ePackage"
	} satisfies ReferenceMeta,
	eSubpackages: {
		target: "EPackage",
		max: -1,
		containment: true,
		opposite: "eSuperPackage"
	} satisfies ReferenceMeta,
	eSuperPackage: {
		target: "EPackage",
		max: 1,
		isParent: true,
		opposite: "eSubpackages"
	} satisfies ReferenceMeta
};
export const EParameterRefs = {
	eOperation: {
		target: "EOperation",
		max: 1,
		isParent: true,
		opposite: "eParameters"
	} satisfies ReferenceMeta
};
export const EReferenceRefs = {
	eOpposite: {
		target: "EReference",
		max: 1
	} satisfies ReferenceMeta,
	eReferenceType: {
		target: "EClass",
		max: 1,
		min: 1,
		//todo: derived
	} satisfies ReferenceMeta,
	eKeys: {
		target: "EAttribute",
		max: -1
	} satisfies ReferenceMeta
};
export const EStructuralFeatureRefs = {
	eContainingClass: {
		target: "EClass",
		max: 1,
		isParent: true,
		opposite: "eStructuralFeatures"
	} satisfies ReferenceMeta
};
export const ETypedElementRefs = {
	eType: {
		target: "EClassifier",
		max: 1
	} satisfies ReferenceMeta,
	eGenericType: {
		target: "EGenericType",
		max: 1,
		containment: true
	} satisfies ReferenceMeta
};
export const EStringToStringMapEntryRefs = {
};
export const EGenericTypeRefs = {
	eUpperBound: {
		target: "EGenericType",
		max: 1,
		containment: true
	} satisfies ReferenceMeta,
	eTypeArguments: {
		target: "EGenericType",
		max: -1,
		containment: true
	} satisfies ReferenceMeta,
	eRawType: {
		target: "EClassifier",
		max: 1,
		min: 1,
		//todo: derived
	} satisfies ReferenceMeta,
	eLowerBound: {
		target: "EGenericType",
		max: 1,
		containment: true
	} satisfies ReferenceMeta,
	eTypeParameter: {
		target: "ETypeParameter",
		max: 1
	} satisfies ReferenceMeta,
	eClassifier: {
		target: "EClassifier",
		max: 1
	} satisfies ReferenceMeta
};
export const ETypeParameterRefs = {
	eBounds: {
		target: "EGenericType",
		max: -1,
		containment: true
	} satisfies ReferenceMeta
};

export const ecoreMeta: ModelDefinition = {
  name: "ecore",
  prefix: "ecore",
  uri: "http://www.eclipse.org/emf/2002/Ecore#//", //because emfular expects complete uri
  classes: {
    	EAttribute: { references: EAttributeRefs },
		EAnnotation: { references: EAnnotationRefs },
		EClass: { references: EClassRefs },
		EClassifier: { references: EClassifierRefs },
		EDataType: { references: EDataTypeRefs },
		EEnum: { references: EEnumRefs },
		EEnumLiteral: { references: EEnumLiteralRefs },
		EFactory: { references: EFactoryRefs },
		EModelElement: { references: EModelElementRefs },
		ENamedElement: { references: ENamedElementRefs },
		EObject: { references: EObjectRefs },
		EOperation: { references: EOperationRefs },
		EPackage: { references: EPackageRefs },
		EParameter: { references: EParameterRefs },
		EReference: { references: EReferenceRefs },
		EStructuralFeature: { references: EStructuralFeatureRefs },
		ETypedElement: { references: ETypedElementRefs },
		EStringToStringMapEntry: { references: EStringToStringMapEntryRefs },
		EGenericType: { references: EGenericTypeRefs },
		ETypeParameter: { references: ETypeParameterRefs },
  }
};
