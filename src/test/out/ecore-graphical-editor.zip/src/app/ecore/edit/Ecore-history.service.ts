import { Inject, Injectable, PLATFORM_ID } from '@angular/core';
import { HistoryService } from 'ngx-emfular-helper';
import { JsonOf } from 'emfular';
import { EPackage } from '../core/EPackage';

@Injectable({
  providedIn: 'root'
})
export class EcoreHistoryService extends HistoryService<JsonOf<EPackage>> {

  constructor(@Inject(PLATFORM_ID) platform: Object) {
    super('Ecore-history_', 50, platform);
  }
}
