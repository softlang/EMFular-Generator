import { Injectable } from '@angular/core';
import { ModelService } from 'ngx-emfular-integration';
import { IoService } from 'ngx-emfular-helper';

import { EcoreHistoryService } from './Ecore-history.service';
import { EAttribute } from "../core/EAttribute";
import { EAnnotation } from "../core/EAnnotation";
import { EClass } from "../core/EClass";
import { EDataType } from "../core/EDataType";
import { EEnum } from "../core/EEnum";
import { EEnumLiteral } from "../core/EEnumLiteral";
import { EFactory } from "../core/EFactory";
import { EObject } from "../core/EObject";
import { EOperation } from "../core/EOperation";
import { EPackage } from "../core/EPackage";
import { EParameter } from "../core/EParameter";
import { EReference } from "../core/EReference";
import { EStringToStringMapEntry } from "../core/EStringToStringMapEntry";
import { EGenericType } from "../core/EGenericType";
import { ETypeParameter } from "../core/ETypeParameter";

@Injectable({
  providedIn: 'root'
})
export class EcoreService extends ModelService<EPackage> {

  constructor(
    historyService: EcoreHistoryService,
    ioService: IoService,
) {
    super(historyService, ioService, EPackage);
  }

	createEAttribute () {
		return new EAttribute()
	}

	createEAnnotation () {
		return new EAnnotation()
	}

	createEClass () {
		return new EClass()
	}

	createEDataType () {
		return new EDataType()
	}

	createEEnum () {
		return new EEnum()
	}

	createEEnumLiteral () {
		return new EEnumLiteral()
	}

	createEFactory () {
		return new EFactory()
	}

	createEObject () {
		return new EObject()
	}

	createEOperation () {
		return new EOperation()
	}

	createEPackage () {
		return new EPackage()
	}

	createEParameter () {
		return new EParameter()
	}

	createEReference () {
		return new EReference()
	}

	createEStringToStringMapEntry () {
		return new EStringToStringMapEntry()
	}

	createEGenericType () {
		return new EGenericType()
	}

	createETypeParameter () {
		return new ETypeParameter()
	}

}
