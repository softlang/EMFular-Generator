import {Component} from '@angular/core';
import {
  TreeModelDetailsService,
  EditButtonDef,
  ModelEditingBarComponent,
  BasicEditorComponent,
  ReferencableBoxComponent
} from "ngx-emfular-integration";
import { BoundingBox } from 'ngx-svg-graphics';
import { Referencable} from "emfular";

import { EcoreService } from "../edit/Ecore.service";
import { EPackage } from "../core/EPackage";

@Component({
  selector: 'Ecore-editor',
  imports: [
    ModelEditingBarComponent,
    BasicEditorComponent,
    ReferencableBoxComponent
  ],
  templateUrl: './Ecore-editor.component.html',
  styleUrl: './Ecore-editor.component.css'
})
export class EcoreEditorComponent{

  svgwidth = 1500;
  svgheigth = 1000;
  initialBBox : BoundingBox = {x: this.svgwidth/2, y: 20, w: 200, h: 25}
  sidebarButtons: Array<EditButtonDef> | null = null;

  constructor(
    public treeDetailsService: TreeModelDetailsService<EPackage>,
    public modelService: EcoreService,
  ) {
    this.sidebarButtons = [
      {
        label: "EAttribute",
        action: () => {
          const res = this.modelService.createEAttribute()
          if(res){
            this.treeDetailsService.openDetails(res, this.modelService)
          }
        }
      },
{
        label: "EAnnotation",
        action: () => {
          const res = this.modelService.createEAnnotation()
          if(res){
            this.treeDetailsService.openDetails(res, this.modelService)
          }
        }
      },
{
        label: "EClass",
        action: () => {
          const res = this.modelService.createEClass()
          if(res){
            this.treeDetailsService.openDetails(res, this.modelService)
          }
        }
      },
{
        label: "EDataType",
        action: () => {
          const res = this.modelService.createEDataType()
          if(res){
            this.treeDetailsService.openDetails(res, this.modelService)
          }
        }
      },
{
        label: "EEnum",
        action: () => {
          const res = this.modelService.createEEnum()
          if(res){
            this.treeDetailsService.openDetails(res, this.modelService)
          }
        }
      },
{
        label: "EEnumLiteral",
        action: () => {
          const res = this.modelService.createEEnumLiteral()
          if(res){
            this.treeDetailsService.openDetails(res, this.modelService)
          }
        }
      },
{
        label: "EFactory",
        action: () => {
          const res = this.modelService.createEFactory()
          if(res){
            this.treeDetailsService.openDetails(res, this.modelService)
          }
        }
      },
{
        label: "EObject",
        action: () => {
          const res = this.modelService.createEObject()
          if(res){
            this.treeDetailsService.openDetails(res, this.modelService)
          }
        }
      },
{
        label: "EOperation",
        action: () => {
          const res = this.modelService.createEOperation()
          if(res){
            this.treeDetailsService.openDetails(res, this.modelService)
          }
        }
      },
{
        label: "EPackage",
        action: () => {
          const res = this.modelService.createEPackage()
          if(res){
            this.treeDetailsService.openDetails(res, this.modelService)
          }
        }
      },
{
        label: "EParameter",
        action: () => {
          const res = this.modelService.createEParameter()
          if(res){
            this.treeDetailsService.openDetails(res, this.modelService)
          }
        }
      },
{
        label: "EReference",
        action: () => {
          const res = this.modelService.createEReference()
          if(res){
            this.treeDetailsService.openDetails(res, this.modelService)
          }
        }
      },
{
        label: "EStringToStringMapEntry",
        action: () => {
          const res = this.modelService.createEStringToStringMapEntry()
          if(res){
            this.treeDetailsService.openDetails(res, this.modelService)
          }
        }
      },
{
        label: "EGenericType",
        action: () => {
          const res = this.modelService.createEGenericType()
          if(res){
            this.treeDetailsService.openDetails(res, this.modelService)
          }
        }
      },
{
        label: "ETypeParameter",
        action: () => {
          const res = this.modelService.createETypeParameter()
          if(res){
            this.treeDetailsService.openDetails(res, this.modelService)
          }
        }
      }
    ]
  }

  choose(element: Referencable<any>) {
    this.treeDetailsService.openDetails(element, this.modelService)
  }

}
